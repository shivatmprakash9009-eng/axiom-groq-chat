import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import {
  Activity, ArrowDown, ArrowLeft, ArrowRight, AudioLines, BookOpen, Bot, Check,
  ChevronDown, CircleHelp, Copy, FileText, FolderKanban, Globe, Info, Layers3,
  Menu, MessageSquare, MoreHorizontal, PanelLeftClose, PanelLeftOpen, Paperclip,
  Pencil, Plus, Search, Send, Settings2, ShieldCheck, Sparkles, Square, Sun,
  ThumbsDown, ThumbsUp, Trash2, X, Zap
} from 'lucide-react';

gsap.registerPlugin(useGSAP);

const MODELS = [
  { id: 'openai/gpt-oss-120b', name: 'GPT OSS 120B', hint: 'Advanced reasoning' },
  { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B', hint: 'Versatile' },
  { id: 'openai/gpt-oss-20b', name: 'GPT OSS 20B', hint: 'Fast and capable' },
  { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant', hint: 'Low latency' }
];
const STORAGE_KEY = 'axiom.groq-chat.v1';
const starters = [
  { icon: <Pencil size={17} />, title: 'Write something', body: 'Draft a message, essay, or story', prompt: 'Help me write a clear, engaging piece about an idea I have.' },
  { icon: <Layers3 size={17} />, title: 'Make a plan', body: 'Turn a big goal into clear steps', prompt: 'Help me turn a goal into a practical plan with milestones and next actions.' },
  { icon: <Bot size={17} />, title: 'Build with AI', body: 'Explore an idea or solve a problem', prompt: 'Help me design an AI-powered product. Ask any important clarifying questions first.' },
  { icon: <FileText size={17} />, title: 'Understand a file', body: 'Summarize, explain, or extract details', prompt: 'Help me analyze the text I attach and extract the most important insights.' }
];
const uid = () => (globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`);
const nowLabel = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

function CodeBlock({ children }) {
  const [copied, setCopied] = useState(false);
  const codeElement = Array.isArray(children) ? children.find(child => child?.type === 'code') : children;
  const extractText = (node) => {
    if (node == null || typeof node === 'boolean') return '';
    if (typeof node === 'string' || typeof node === 'number') return String(node);
    if (Array.isArray(node)) return node.map(extractText).join('');
    if (node?.props) return extractText(node.props.children);
    return '';
  };
  const content = extractText(codeElement?.props?.children);
  const lang = codeElement?.props?.className?.replace('language-', '') || 'code';
  const copy = async () => {
    try { await navigator.clipboard.writeText(content); setCopied(true); setTimeout(() => setCopied(false), 1400); }
    catch { /* Clipboard may be blocked by browser permissions. */ }
  };
  return <div className="code-block"><div className="code-top"><span>{lang}</span><button onClick={copy} className="code-copy"><Copy size={13} />{copied ? 'Copied' : 'Copy code'}</button></div><pre>{children}</pre></div>;
}

function Markdown({ content }) {
  return <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]} components={{ pre: CodeBlock }}>
    {content || ''}
  </ReactMarkdown>;
}

function Modal({ title, eyebrow, onClose, children, wide = false }) {
  useEffect(() => {
    const onKey = (event) => event.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
    <motion.section className={`modal ${wide ? 'modal-wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} initial={{ opacity: 0, y: 14, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: .99 }} transition={{ type: 'spring', stiffness: 340, damping: 28 }}>
      <header className="modal-header"><div>{eyebrow && <p className="modal-eyebrow">{eyebrow}</p>}<h2>{title}</h2></div><button className="icon-action" onClick={onClose} aria-label="Close"><X size={18}/></button></header>
      <div className="modal-body">{children}</div>
    </motion.section>
  </motion.div>;
}

export default function App() {
  const reducedMotion = useReducedMotion();
  const shellRef = useRef(null);
  const composerRef = useRef(null);
  const textareaRef = useRef(null);
  const fileRef = useRef(null);
  const streamAbort = useRef(null);
  const [chats, setChats] = useState(() => {
    try { const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); return Array.isArray(stored) ? stored : []; }
    catch { return []; }
  });
  const [activeId, setActiveId] = useState(null);
  const [draft, setDraft] = useState('');
  const [model, setModel] = useState('openai/gpt-oss-120b');
  const [modelMenu, setModelMenu] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [modal, setModal] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [health, setHealth] = useState({ loaded: false, configured: false, provider: 'Groq' });
  const [generatingId, setGeneratingId] = useState(null);
  const [toastText, setToastText] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [showScrollDown, setShowScrollDown] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [rotatingPrompt, setRotatingPrompt] = useState(0);
  const endRef = useRef(null);
  const messagesPaneRef = useRef(null);

  const activeChat = chats.find(chat => chat.id === activeId) || null;
  const messages = activeChat?.messages || [];
  const isLanding = messages.length === 0;
  const isGenerating = generatingId === activeId && Boolean(generatingId);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(chats.slice(0, 80))); } catch { /* storage may be unavailable */ }
  }, [chats]);

  useEffect(() => {
    let live = true;
    fetch('/api/health').then(r => r.json()).then(data => { if (live) setHealth({ ...data, loaded: true }); })
      .catch(() => { if (live) setHealth({ loaded: true, configured: false, offline: true, provider: 'Groq' }); });
    return () => { live = false; };
  }, []);

  useEffect(() => {
    if (!isLanding || reducedMotion) return undefined;
    const interval = window.setInterval(() => setRotatingPrompt(v => (v + 1) % starters.length), 3600);
    return () => window.clearInterval(interval);
  }, [isLanding, reducedMotion]);

  useGSAP(() => {
    if (!isLanding || reducedMotion) return;
    gsap.fromTo('.hero-word', { y: 18, opacity: 0, filter: 'blur(5px)' }, {
      y: 0, opacity: 1, filter: 'blur(0px)', duration: .75, ease: 'power3.out', stagger: .075, clearProps: 'filter'
    });
    gsap.fromTo('.hero-entrance', { y: 14, opacity: 0 }, {
      y: 0, opacity: 1, duration: .65, delay: .18, ease: 'power2.out', stagger: .09
    });
  }, { scope: shellRef, dependencies: [isLanding, activeId], revertOnUpdate: true });

  useEffect(() => {
    const el = messagesPaneRef.current;
    if (!el || isLanding) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 220;
    if (nearBottom || isGenerating) endRef.current?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'end' });
    setShowScrollDown(el.scrollHeight - el.scrollTop - el.clientHeight > 280);
  }, [messages, isLanding, isGenerating, reducedMotion]);

  const showToast = useCallback((text) => {
    setToastText(text);
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => setToastText(''), 2500);
  }, []);

  const makeNewChat = useCallback(() => {
    if (streamAbort.current) { streamAbort.current.abort(); streamAbort.current = null; }
    setGeneratingId(null);
    const id = uid();
    setChats(prev => [{ id, title: 'New chat', createdAt: Date.now(), messages: [] }, ...prev]);
    setActiveId(id);
    setDraft('');
    setAttachment(null);
    setModelMenu(false);
    setMobileSidebar(false);
    setTimeout(() => textareaRef.current?.focus(), 80);
  }, []);

  useEffect(() => {
    const onShortcut = (event) => {
      if (!(event.metaKey || event.ctrlKey) || event.altKey) return;
      const key = event.key.toLowerCase();
      if (key === 'k') { event.preventDefault(); makeNewChat(); }
      if (key === 'f') { event.preventDefault(); setSearchTerm(''); setModal('search'); }
    };
    window.addEventListener('keydown', onShortcut);
    return () => window.removeEventListener('keydown', onShortcut);
  }, [makeNewChat]);

  const selectChat = useCallback((id) => {
    if (streamAbort.current) { streamAbort.current.abort(); streamAbort.current = null; setGeneratingId(null); }
    setActiveId(id);
    setMobileSidebar(false);
    setModelMenu(false);
  }, []);

  const updateMessage = (chatId, messageId, updater) => {
    setChats(prev => prev.map(chat => chat.id !== chatId ? chat : {
      ...chat,
      messages: chat.messages.map(message => message.id === messageId ? updater(message) : message),
      updatedAt: Date.now()
    }));
  };

  const sendMessage = useCallback(async (textOverride) => {
    const text = (textOverride ?? draft).trim();
    if ((!text && !attachment) || generatingId) return;
    const currentId = activeId || uid();
    const userText = text || `Please analyze the attached file: ${attachment?.name || 'file'}`;
    const userMessage = {
      id: uid(), role: 'user', content: userText, createdAt: Date.now(),
      fileName: attachment?.name || null, fileContent: attachment?.content || null
    };
    const assistantMessage = { id: uid(), role: 'assistant', content: '', createdAt: Date.now() };
    const existed = chats.some(chat => chat.id === currentId);
    setChats(prev => {
      const current = prev.find(chat => chat.id === currentId);
      if (current) return prev.map(chat => chat.id === currentId ? {
        ...chat,
        title: chat.messages.length === 0 ? userText.slice(0, 42) + (userText.length > 42 ? '…' : '') : chat.title,
        updatedAt: Date.now(), messages: [...chat.messages, userMessage, assistantMessage]
      } : chat);
      return [{ id: currentId, title: userText.slice(0, 42) + (userText.length > 42 ? '…' : ''), createdAt: Date.now(), updatedAt: Date.now(), messages: [userMessage, assistantMessage] }, ...prev];
    });
    if (!existed) setActiveId(currentId);
    setDraft('');
    setAttachment(null);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setGeneratingId(currentId);
    const controller = new AbortController();
    streamAbort.current = controller;

    const history = [...(activeChat?.id === currentId ? activeChat.messages : []), userMessage]
      .slice(-30)
      .map(message => ({
        role: message.role,
        content: message.fileContent
          ? `${message.content}\n\n[Attached text file: ${message.fileName}]\n--- FILE CONTENT START ---\n${message.fileContent}\n--- FILE CONTENT END ---`
          : message.content
      }));

    let fullText = '';
    try {
      const response = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages: history }), signal: controller.signal
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || `Request failed (${response.status})`);
      }
      if (!response.body) throw new Error('Streaming is not supported by this browser.');
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let completed = false;
      const handleLine = (line) => {
        if (!line.startsWith('data:')) return;
        const raw = line.slice(5).trim();
        if (!raw) return;
        try {
          const event = JSON.parse(raw);
          if (event.delta) {
            fullText += event.delta;
            updateMessage(currentId, assistantMessage.id, message => ({ ...message, content: fullText }));
          }
          if (event.error) {
            fullText += `\n\n**Error:** ${event.error}`;
            updateMessage(currentId, assistantMessage.id, message => ({ ...message, content: fullText }));
            completed = true;
          }
          if (event.done) completed = true;
        } catch { /* Ignore incomplete or unrelated stream packets. */ }
      };
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        lines.forEach(handleLine);
        if (completed) break;
      }
      if (buffer.trim()) handleLine(buffer.trim());
      if (!fullText && !completed) fullText = 'The model returned an empty response. Please try again.';
      if (fullText) updateMessage(currentId, assistantMessage.id, message => ({ ...message, content: fullText }));
    } catch (error) {
      if (error?.name === 'AbortError') {
        if (!fullText) updateMessage(currentId, assistantMessage.id, message => ({ ...message, content: '_Generation stopped._' }));
      } else {
        const message = `**Couldn't complete that request.**\n\n${error?.message || 'Something went wrong.'}\n\n${error?.message?.includes('API key') || error?.message?.includes('GROQ_API_KEY') ? 'Add your key to the project’s `.env` file and restart the server.' : 'Check your connection, model selection, and Groq API quota, then try again.'}`;
        updateMessage(currentId, assistantMessage.id, previous => ({ ...previous, content: message }));
      }
    } finally {
      if (streamAbort.current === controller) streamAbort.current = null;
      setGeneratingId(null);
    }
  }, [activeId, activeChat, attachment, chats, draft, generatingId, model]);

  const stopGeneration = () => {
    streamAbort.current?.abort();
    streamAbort.current = null;
    setGeneratingId(null);
  };

  const deleteChat = (id) => {
    setChats(prev => prev.filter(chat => chat.id !== id));
    if (activeId === id) setActiveId(null);
    showToast('Conversation deleted');
  };

  const copyText = async (text) => {
    try { await navigator.clipboard.writeText(text); showToast('Copied to clipboard'); }
    catch { showToast('Clipboard permission unavailable'); }
  };

  const handleFile = (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!/\.(txt|md|csv|json|html|log)$/i.test(file.name)) {
      showToast('For now, attach a text, Markdown, CSV, JSON, HTML, or LOG file.'); return;
    }
    if (file.size > 180 * 1024) { showToast('Please keep text files under 180 KB.'); return; }
    const reader = new FileReader();
    reader.onload = () => { setAttachment({ name: file.name, content: String(reader.result || '') }); showToast(`${file.name} attached`); };
    reader.onerror = () => showToast('Could not read that file');
    reader.readAsText(file);
  };

  const filteredChats = useMemo(() => {
    const sorted = [...chats].filter(chat => chat.messages.length).sort((a,b) => (b.updatedAt || b.createdAt) - (a.updatedAt || a.createdAt));
    return searchTerm.trim() ? sorted.filter(chat => `${chat.title} ${chat.messages.map(m=>m.content).join(' ')}`.toLowerCase().includes(searchTerm.toLowerCase())) : sorted;
  }, [chats, searchTerm]);
  const groupedChats = useMemo(() => {
    const today = new Date(); today.setHours(0,0,0,0);
    const yesterday = today.getTime() - 86400000;
    const groups = [{ label: 'Today', items: [] }, { label: 'Yesterday', items: [] }, { label: 'Previous 7 days', items: [] }, { label: 'Older', items: [] }];
    filteredChats.forEach(chat => {
      const day = new Date(chat.updatedAt || chat.createdAt); day.setHours(0,0,0,0);
      const t = day.getTime();
      const index = t >= today.getTime() ? 0 : t >= yesterday ? 1 : t >= today.getTime() - 7*86400000 ? 2 : 3;
      groups[index].items.push(chat);
    });
    return groups.filter(group => group.items.length);
  }, [filteredChats]);

  const onComposerKey = (event) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault(); sendMessage();
    }
  };

  return <div ref={shellRef} className={`app-shell ${darkMode ? 'dark-theme' : ''}`}>
    <AnimatePresence initial={false}>
      {mobileSidebar && <motion.div className="mobile-scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileSidebar(false)} />}
    </AnimatePresence>
    <motion.aside className={`sidebar ${sidebarOpen ? 'sidebar-wide' : 'sidebar-rail'} ${mobileSidebar ? 'sidebar-mobile-open' : ''}`}
      initial={false} animate={{ width: sidebarOpen ? 264 : 68 }} transition={{ duration: .24, ease: 'easeInOut' }}>
      <div className="sidebar-top">
        <button className="brand-button" onClick={() => { setActiveId(null); setDraft(''); }} aria-label="Axiom home">
          <span className="brand-mark"><Sparkles size={18} strokeWidth={2.25}/></span>{sidebarOpen && <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="brand-name">axiom<span>.</span></motion.span>}
        </button>
        <button className="icon-action sidebar-collapse" title={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'} onClick={() => setSidebarOpen(v => !v)}>{sidebarOpen ? <PanelLeftClose size={18}/> : <PanelLeftOpen size={18}/>}</button>
      </div>
      <div className="sidebar-actions">
        <button className="nav-action active-action" onClick={makeNewChat} title="New chat"><Plus size={18}/>{sidebarOpen && <span>New chat</span>}<kbd className="new-shortcut">⌘ K</kbd></button>
        <button className="nav-action" onClick={() => { setSearchTerm(''); setModal('search'); }} title="Search chats"><Search size={18}/>{sidebarOpen && <span>Search chats</span>}<kbd>⌘ F</kbd></button>
        <button className="nav-action" onClick={() => setModal('library')} title="Library"><BookOpen size={18}/>{sidebarOpen && <span>Library</span>}</button>
        <button className="nav-action" onClick={() => setModal('projects')} title="Projects"><FolderKanban size={18}/>{sidebarOpen && <span>Projects</span>}</button>
      </div>
      {sidebarOpen && <div className="history-wrap">
        <div className="section-label">Your conversations</div>
        <div className="history-list">
          {groupedChats.length ? groupedChats.map(group => <div className="history-group" key={group.label}>
            <div className="history-date">{group.label}</div>
            {group.items.map(chat => <div key={chat.id} className={`history-entry ${activeId === chat.id ? 'history-selected' : ''}`}>
              <button className="history-title" onClick={() => selectChat(chat.id)} title={chat.title}><MessageSquare size={14}/><span>{chat.title}</span></button>
              <button className="history-more" aria-label="Delete conversation" onClick={() => deleteChat(chat.id)} title="Delete conversation"><MoreHorizontal size={16}/></button>
            </div>)}
          </div>) : <div className="empty-history"><span className="empty-history-icon"><MessageSquare size={17}/></span><span>Your conversations will<br/>appear here.</span></div>}
        </div>
      </div>}
      <div className="sidebar-bottom">
        {sidebarOpen && <div className={`connection-card ${health.configured ? 'connected' : ''}`}><span className="connection-dot"/><div><strong>{health.configured ? 'Groq connected' : 'Connect Groq API'}</strong><small>{health.loaded ? (health.configured ? 'Ready for your prompts' : 'Add your key in .env') : 'Checking connection…'}</small></div><button onClick={() => setModal('settings')} aria-label="Connection settings"><Settings2 size={15}/></button></div>}
        <button className="profile-row" onClick={() => setModal('settings')} title="Settings"><span className="profile-avatar">S</span>{sidebarOpen && <span className="profile-text"><strong>Personal workspace</strong><small>Free plan · Groq API</small></span>}{sidebarOpen && <MoreHorizontal size={17} className="profile-more"/>}</button>
      </div>
    </motion.aside>

    <main className="main-area">
      <header className="topbar">
        <div className="topbar-left"><button className="topbar-icon mobile-menu-button" aria-label="Open sidebar" onClick={() => setMobileSidebar(true)}><Menu size={19}/></button><button className="model-select" onClick={() => setModelMenu(v => !v)} aria-expanded={modelMenu}><span className="model-spark"><Sparkles size={15}/></span><span>{MODELS.find(item=>item.id===model)?.name || 'Axiom'}</span><ChevronDown size={15} className={modelMenu ? 'chevron-up' : ''}/></button>
          <AnimatePresence>{modelMenu && <motion.div className="model-dropdown" initial={{ opacity: 0, y: 7, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 5 }} transition={{ duration: .14 }}>
            <div className="dropdown-heading">Choose a model</div>{MODELS.map(item => <button key={item.id} className={`model-option ${item.id === model ? 'model-option-selected' : ''}`} onClick={() => { setModel(item.id); setModelMenu(false); showToast(`${item.name} selected`); }}><span className="model-option-icon"><Zap size={15}/></span><span className="model-option-copy"><strong>{item.name}</strong><small>{item.hint}</small></span>{item.id === model && <Check size={16}/>}</button>)}<div className="dropdown-note">Models available through your Groq account.</div>
          </motion.div>}</AnimatePresence>
        </div>
        <div className="topbar-right"><span className={`api-indicator ${health.configured ? 'api-on' : ''}`}><span/>{health.configured ? 'API ready' : 'Local setup'}</span><button className="topbar-icon" title="Settings" onClick={() => setModal('settings')}><Settings2 size={18}/></button><button className="share-button" onClick={() => { if (!activeChat || !messages.length) showToast('Start a conversation to export it'); else { const text = messages.map(m => `${m.role.toUpperCase()}\n${m.content}`).join('\n\n---\n\n'); const blob = new Blob([text], { type: 'text/markdown' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `${activeChat.title.replace(/[^a-z0-9]+/gi,'-').slice(0,40)||'axiom-chat'}.md`; a.click(); URL.revokeObjectURL(url); showToast('Conversation exported'); } }}><ArrowDown size={15}/><span>Export</span></button></div>
      </header>

      <div className={`workspace ${isLanding ? 'workspace-home' : 'workspace-chat'}`}>
        {isLanding ? <div className="landing" key="landing">
          <div className="landing-topline hero-entrance"><span className="online-pulse"/> A clearer way to think</div>
          <h1 className="hero-title" aria-label="What can I help you with?"><span className="hero-line">{['What','can','I'].map((word,i)=><span key={i} className="hero-word">{word}&nbsp;</span>)}</span><span className="hero-line accent-line">{['help','you','with?'].map((word,i)=><span key={i} className="hero-word">{word}{i<2?' ':''}</span>)}</span></h1>
          <motion.p key={rotatingPrompt} className="landing-subtitle" initial={reducedMotion ? {opacity:1} : {opacity:0,y:6}} animate={{opacity:1,y:0}} transition={{duration:.35}}>{['A thoughtful assistant for ideas, work, and everything in between.','From first principles to finished work. Let’s make progress.','Ask the hard question. Explore the possibilities.','Bring a file, a question, or just a starting point.'][rotatingPrompt]}</motion.p>
          <div className="home-composer-wrap">
            <Composer draft={draft} setDraft={setDraft} onSend={() => sendMessage()} generating={false} onStop={stopGeneration} onKeyDown={onComposerKey} textareaRef={textareaRef} composerRef={composerRef} onAttach={() => fileRef.current?.click()} attachment={attachment} onRemoveAttachment={() => setAttachment(null)} />
            <div className="composer-disclaimer">Axiom can make mistakes. Verify important information.</div>
          </div>
          <div className="starter-grid">
            {starters.map((item,i)=><motion.button key={item.title} className={`starter-card hero-entrance ${rotatingPrompt === i ? 'starter-card-active' : ''}`} onClick={() => { setDraft(item.prompt); textareaRef.current?.focus(); }} whileHover={reducedMotion ? {} : {y:-3}} whileTap={{scale:.985}} transition={{type:'spring',stiffness:330,damping:22}}><span className="starter-icon">{item.icon}</span><span className="starter-copy"><strong>{item.title}</strong><small>{item.body}</small></span><ArrowRight size={15} className="starter-arrow"/></motion.button>)}
          </div>
          <div className="landing-footnote hero-entrance"><ShieldCheck size={14}/> Your API key stays on your server <span>·</span><span>Powered by Groq</span></div>
        </div> : <div className="chat-stage" key={activeId}>
          <div className="message-list" ref={messagesPaneRef}>
            {messages.map((message, index) => <motion.article key={message.id} className={`message-row ${message.role === 'user' ? 'user-row' : 'assistant-row'}`} initial={reducedMotion ? false : { opacity: 0, y: 9 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .24, ease: 'easeOut' }}>
              {message.role === 'assistant' ? <div className="assistant-avatar"><Sparkles size={15}/></div> : null}
              <div className={`message-body ${message.role === 'user' ? 'user-message-body' : ''}`}>
                {message.role === 'user' ? <div className="user-bubble">{message.fileName && <div className="file-attachment-line"><FileText size={14}/><span>{message.fileName}</span></div>}<div>{message.content}</div></div> : <div className="assistant-content">
                  {message.content ? <Markdown content={message.content}/> : <div className="typing-state"><span className="typing-orb"><Sparkles size={14}/></span><span className="typing-label">Thinking</span><span className="typing-dots"><i/><i/><i/></span></div>}
                  {message.content && !(isGenerating && index === messages.length - 1) && <div className="message-toolbar"><button onClick={() => copyText(message.content)} title="Copy response"><Copy size={14}/><span>Copy</span></button><button onClick={() => showToast('Feedback saved')} title="Good response"><ThumbsUp size={14}/></button><button onClick={() => showToast('Feedback saved')} title="Bad response"><ThumbsDown size={14}/></button><span className="message-time">{nowLabel()}</span></div>}
                </div>}
              </div>
            </motion.article>)}
            <div ref={endRef} className="end-anchor"/>
          </div>
          {showScrollDown && <button className="scroll-bottom" onClick={() => endRef.current?.scrollIntoView({behavior:'smooth'})} aria-label="Scroll to bottom"><ArrowDown size={16}/></button>}
          <div className="chat-composer-dock"><Composer draft={draft} setDraft={setDraft} onSend={() => sendMessage()} generating={isGenerating} onStop={stopGeneration} onKeyDown={onComposerKey} textareaRef={textareaRef} composerRef={composerRef} onAttach={() => fileRef.current?.click()} attachment={attachment} onRemoveAttachment={() => setAttachment(null)} /><div className="composer-disclaimer">Axiom is AI and can make mistakes. Verify important information.</div></div>
        </div>}
      </div>
      <input ref={fileRef} type="file" hidden accept=".txt,.md,.csv,.json,.html,.log,text/plain,text/markdown,text/csv,application/json" onChange={handleFile}/>
    </main>

    <AnimatePresence>
      {modal === 'settings' && <Modal title="Settings" eyebrow="AXIOM WORKSPACE" onClose={() => setModal(null)}>
        <div className="settings-section"><div className="settings-title"><span className="settings-icon"><Activity size={17}/></span><div><strong>Groq connection</strong><small>Secure server-side API configuration</small></div><span className={`status-pill ${health.configured ? 'status-good' : 'status-warn'}`}>{health.configured ? 'Connected' : 'Not connected'}</span></div>
          <div className="settings-callout"><Info size={16}/><span>{health.configured ? 'Your server reports that the Groq API key is configured.' : 'Create a .env file from .env.example, add your Groq key, and restart the server. The key should never be placed in frontend code.'}</span></div>
          <div className="settings-row"><span>Provider</span><strong>Groq Cloud</strong></div><div className="settings-row"><span>Selected model</span><strong>{MODELS.find(x=>x.id===model)?.name}</strong></div><div className="settings-row"><span>Connection check</span><button className="mini-button" onClick={() => fetch('/api/health').then(r=>r.json()).then(data=>{setHealth({...data,loaded:true});showToast(data.configured?'Groq connection is ready':'API key is not configured')}).catch(()=>{setHealth({loaded:true,configured:false,offline:true});showToast('Could not reach the local API server')})}>Test connection</button></div>
        </div>
        <div className="settings-section"><div className="settings-title"><span className="settings-icon"><Sun size={17}/></span><div><strong>Appearance</strong><small>Choose the workspace theme</small></div></div><div className="theme-choice-row"><button className={`theme-choice ${!darkMode?'theme-choice-selected':''}`} onClick={()=>setDarkMode(false)}><span className="theme-swatch light-swatch"/><span>Light</span>{!darkMode&&<Check size={15}/>}</button><button className={`theme-choice ${darkMode?'theme-choice-selected':''}`} onClick={()=>setDarkMode(true)}><span className="theme-swatch dark-swatch"/><span>Dark</span>{darkMode&&<Check size={15}/>}</button></div></div>
        <div className="modal-footer-note"><ShieldCheck size={14}/> API keys are handled by the backend and are not sent to the browser.</div>
      </Modal>}
      {modal === 'search' && <Modal title="Search conversations" eyebrow="YOUR HISTORY" onClose={() => setModal(null)} wide>
        <div className="search-modal-field"><Search size={18}/><input autoFocus value={searchTerm} onChange={e=>setSearchTerm(e.target.value)} placeholder="Search titles and message content…"/><kbd>ESC</kbd></div>
        <div className="search-results">{filteredChats.length ? filteredChats.map(chat=><button className="search-result" key={chat.id} onClick={()=>{selectChat(chat.id);setModal(null)}}><MessageSquare size={16}/><span><strong>{chat.title}</strong><small>{chat.messages.length} messages · {new Date(chat.updatedAt||chat.createdAt).toLocaleDateString()}</small></span><ArrowRight size={15}/></button>) : <div className="modal-empty"><Search size={22}/><strong>No conversations found</strong><span>Try another search, or start a new chat.</span></div>}</div>
      </Modal>}
      {modal === 'library' && <Modal title="Your library" eyebrow="SAVED WORK" onClose={() => setModal(null)}>
        <div className="library-intro"><div className="library-illustration"><BookOpen size={25}/></div><h3>A home for useful answers.</h3><p>Export any conversation as Markdown using the Export button. Saved conversations stay in this browser on this device.</p></div>
        <div className="library-stat-row"><div><strong>{chats.filter(c=>c.messages.length).length}</strong><span>Conversations</span></div><div><strong>{chats.reduce((n,c)=>n+c.messages.length,0)}</strong><span>Total messages</span></div></div>
        <button className="modal-primary" onClick={()=>{setModal(null);showToast('Use Export in the top bar to save a conversation')}}>How to export chats <ArrowRight size={15}/></button>
      </Modal>}
      {modal === 'projects' && <Modal title="Projects" eyebrow="WORKSPACES" onClose={() => setModal(null)}>
        <div className="library-intro"><div className="library-illustration"><FolderKanban size={25}/></div><h3>Keep related work together.</h3><p>Project folders are a workspace feature planned for a later version. Your current conversations are available in the sidebar and browser storage.</p></div>
        <button className="modal-primary" onClick={()=>{setModal(null);makeNewChat()}}>Start a new conversation <Plus size={15}/></button>
      </Modal>}
    </AnimatePresence>
    <AnimatePresence>{toastText && <motion.div className="toast-message" initial={{opacity:0,y:12,scale:.96}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:8}}><Check size={15}/>{toastText}</motion.div>}</AnimatePresence>
    <div className="global-shortcuts" aria-hidden="true">Axiom · Private workspace</div>
  </div>;
}

function Composer({ draft, setDraft, onSend, generating, onStop, onKeyDown, textareaRef, composerRef, onAttach, attachment, onRemoveAttachment }) {
  const [toolsOpen, setToolsOpen] = useState(false);
  const hasText = draft.trim().length > 0 || Boolean(attachment);
  const resize = (event) => {
    setDraft(event.target.value);
    event.target.style.height = 'auto';
    event.target.style.height = `${Math.min(event.target.scrollHeight, 200)}px`;
  };
  return <div className="composer-shell" ref={composerRef}>
    {attachment && <div className="attachment-preview"><span className="attachment-file-icon"><FileText size={15}/></span><span className="attachment-label"><strong>{attachment.name}</strong><small>Text file · attached for context</small></span><button onClick={onRemoveAttachment} aria-label="Remove attachment"><X size={15}/></button></div>}
    <textarea ref={textareaRef} rows={1} value={draft} onChange={resize} onKeyDown={onKeyDown} placeholder="Message Axiom…" aria-label="Write your message" />
    <div className="composer-controls">
      <div className="composer-left-tools">
        <div className="composer-tools-wrap"><button className={`composer-tool plus-tool ${toolsOpen?'tool-selected':''}`} onClick={()=>setToolsOpen(v=>!v)} aria-label="Add context" aria-expanded={toolsOpen}><Plus size={20}/></button>
          <AnimatePresence>{toolsOpen && <motion.div className="tools-popover" initial={{opacity:0,y:7,scale:.98}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:4}}><button onClick={()=>{onAttach();setToolsOpen(false)}}><Paperclip size={16}/><span><strong>Attach text file</strong><small>TXT, MD, CSV, JSON, HTML</small></span></button><div className="tools-popover-note">Files are sent to Groq as message context.</div></motion.div>}</AnimatePresence>
        </div>
        <span className="composer-hint"><span className="hint-dot"/> AI assistant <span className="hint-separator">·</span> <kbd>↵</kbd> to send</span>
      </div>
      <div className="composer-right-tools"><button className="composer-tool voice-tool" title="Voice mode is not configured"><AudioLines size={18}/></button>
        {generating ? <button className="send-button stop-button" onClick={onStop} aria-label="Stop generating"><Square size={14} fill="currentColor"/></button> : <button className="send-button" onClick={onSend} disabled={!hasText} aria-label="Send message"><Send size={17} strokeWidth={2.3}/></button>}
      </div>
    </div>
  </div>;
}

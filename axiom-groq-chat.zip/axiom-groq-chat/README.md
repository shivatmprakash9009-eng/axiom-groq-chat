# Axiom — Groq-powered AI chat

A responsive ChatGPT-inspired chat workspace built with React, Vite, Framer Motion, GSAP, Express, Markdown rendering, and Groq's OpenAI-compatible Chat Completions API.

## Included

- ChatGPT-inspired layout: collapsible sidebar, conversation history, model picker, starter prompts, prompt composer, export, settings, and search.
- Motion design: GSAP entrance/text animation, Framer Motion transitions, responsive cards, typing state, and modal transitions.
- Groq streaming responses (server → browser SSE), model selection, stop generation, Markdown/GFM/code blocks, copy response and copy-code controls.
- Browser-local conversation history (localStorage) and Markdown export.
- Text/Markdown/CSV/JSON/HTML/LOG attachment support (up to 180 KB) for passing text file contents as prompt context.
- Server-side API key handling, model allow-list, request body limits, rate limiting, and health endpoint.
- Light/dark appearance switch; mobile navigation.

## Requirements

- Node.js 18.18+ (Node 20 LTS recommended)
- npm
- A Groq API key from <https://console.groq.com/keys>

## Setup

1. Extract the project ZIP and open a terminal in the project folder.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Create your local environment file:

   **macOS / Linux**
   ```bash
   cp .env.example .env
   ```

   **Windows PowerShell**
   ```powershell
   Copy-Item .env.example .env
   ```

4. Open `.env` and replace the placeholder with your key:

   ```env
   GROQ_API_KEY=gsk_your_real_key_here
   PORT=8787
   DEFAULT_MODEL=openai/gpt-oss-120b
   ```

5. Start the application:

   ```bash
   npm run dev
   ```

6. Open <http://localhost:5173>.

The UI is served by Vite in development, which proxies `/api` requests to the Express backend on port `8787`. Check the green API status indicator or Settings → Test connection.

## Production build

```bash
npm run build
npm start
```

The Express server serves `dist/` when the production build exists. Configure `GROQ_API_KEY`, `PORT`, and `DEFAULT_MODEL` in the hosting provider's environment settings. Do not deploy `.env` or commit it to Git.

## API endpoints

- `GET /api/health` — configured/not configured status (never returns the key)
- `GET /api/models` — enabled model list
- `POST /api/chat` — streams chat deltas as Server-Sent Events

The backend currently enables these model IDs: `openai/gpt-oss-120b`, `openai/gpt-oss-20b`, `llama-3.3-70b-versatile`, and `llama-3.1-8b-instant`. Availability may depend on the current Groq account and model lifecycle. Edit `ALLOWED_MODELS` in `server/index.js` and the `MODELS` array in `src/App.jsx` together if you change the list.

## Security / production notes

- Never paste the Groq key into `src/`, `index.html`, a browser setting, or a public repository. The key should be only in `.env` locally or your deployment provider's secret/environment manager.
- The included rate limiter is a starting point, not a complete public multi-user security system. Before exposing the app publicly, add authentication, a persistent shared rate limiter, usage monitoring, and deployment-specific protections.
- Chats are stored in this browser's `localStorage`; do not use this on a shared device for sensitive conversations. Clearing browser storage removes them. No database or account login is included.
- Attachments are read as text in the browser and sent to your server/Groq as prompt context. The current version does not upload binary files or parse PDFs/images.
- Account, projects, voice mode, and checkout-style controls are not connected to external services. The Projects dialog explains this limitation; the voice icon is a visual placeholder.
- AI output can be inaccurate. Verify important information and review applicable Groq terms, privacy requirements, and data handling before using with sensitive information.

## Customization

- Branding/colors/typography: `src/styles.css` and `<title>` in `index.html`.
- Opening screen and interaction logic: `src/App.jsx`.
- Groq model list, streaming, rate limits: `server/index.js`.
